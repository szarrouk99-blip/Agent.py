import logging

logger = logging.getLogger(__name__)

class OpsCoordinatorAgent:
    async def node_execute(self, state):
        state["last_node"] = "ops_coordinator"
        return state
