import logging

logger = logging.getLogger(__name__)

class BusinessDevAgent:
    async def node_execute(self, state):
        state["last_node"] = "business_dev"
        return state
