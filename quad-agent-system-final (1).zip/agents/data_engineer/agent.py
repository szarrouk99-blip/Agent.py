import os, logging
from supabase import create_client
from langchain_openai import ChatOpenAI
from infra.circuit_breaker import supabase_cb
from supervisor.limits import update_token_usage

logger = logging.getLogger(__name__)

class DataEngineerAgent:
    def __init__(self):
        self.supabase = create_client(os.getenv("SUPABASE_URL"), os.getenv("SUPABASE_KEY"))
        self.llm = ChatOpenAI(model="gpt-4o", temperature=0)

    @supabase_cb
    async def insert_record(self, table, data):
        response = self.supabase.table(table).insert(data).execute()
        return {"status": "success", "data": response.data}

    async def node_execute(self, state):
        try:
            response = await self.llm.ainvoke(state["messages"])
            state = update_token_usage(state, response.dict())
            state["last_node"] = "data_engineer"
            state["messages"].append(response.content)
            return state
        except Exception as e:
            logger.error(f"Data Engineer failed: {e}")
            state["dlq_payload"] = {"error": str(e)}
            return state
