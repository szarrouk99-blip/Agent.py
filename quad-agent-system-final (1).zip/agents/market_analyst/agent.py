import logging
from infra.circuit_breaker import bybit_cb

logger = logging.getLogger(__name__)

class MarketAnalystAgent:
    def __init__(self):
        pass

    @bybit_cb
    async def subscribe_tickers(self, symbols):
        logger.info(f"Subscribed to {symbols}")

    async def node_execute(self, state):
        state["last_node"] = "market_analyst"
        return state
