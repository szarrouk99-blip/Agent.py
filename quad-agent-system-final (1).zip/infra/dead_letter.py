import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class DeadLetterQueue:
    def __init__(self, supabase_client):
        self.supabase = supabase_client
        self.max_retries = 3

    async def record_failure(self, agent_name, task_payload, error_message, retry_count=0):
        if retry_count >= self.max_retries:
            try:
                data = {
                    "agent_name": agent_name,
                    "task_payload": task_payload,
                    "error_message": error_message,
                    "retry_count": retry_count,
                    "created_at": datetime.utcnow().isoformat(),
                }
                self.supabase.table("dead_letter_queue").insert(data).execute()
                logger.critical(f"DLQ: Task recorded for {agent_name}")
            except Exception as e:
                logger.error(f"DLQ insert failed: {e}")
