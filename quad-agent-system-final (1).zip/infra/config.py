import os
from dotenv import load_dotenv
load_dotenv()

def get_env(key, required=True, default=None):
    value = os.getenv(key, default)
    if required and not value:
        raise EnvironmentError(f"Missing env var: {key}")
    return value

SUPABASE_URL = get_env("SUPABASE_URL")
SUPABASE_KEY = get_env("SUPABASE_KEY")
MAX_STEPS = int(get_env("MAX_STEPS", default="15"))
TOKEN_BUDGET = int(get_env("TOKEN_BUDGET", default="50000"))
