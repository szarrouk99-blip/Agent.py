from typing import TypedDict, Annotated, Optional, List
from langgraph.graph import add_messages

class AgentState(TypedDict):
    messages: Annotated[list, add_messages]
    total_tokens_used: int
    current_model: str
    thread_id: str
    step_count: int
    last_node: str
    dlq_payload: Optional[dict]
