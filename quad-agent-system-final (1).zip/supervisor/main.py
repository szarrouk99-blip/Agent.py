import sys, os, uuid, asyncio
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from supervisor.graph import graph

async def run_task(task):
    thread_id = str(uuid.uuid4())
    initial_state = {
        "messages": [{"role": "user", "content": task}],
        "total_tokens_used": 0,
        "current_model": "gpt-4o",
        "thread_id": thread_id,
        "step_count": 0,
        "last_node": "",
        "dlq_payload": None,
    }
    config = {"configurable": {"thread_id": thread_id}}
    result = await graph.ainvoke(initial_state, config=config)
    return result

if __name__ == "__main__":
    result = asyncio.run(run_task("اكتشف فرصاً في التكنولوجيا المالية"))
    print(result)
