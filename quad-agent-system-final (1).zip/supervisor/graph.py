import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from langgraph.graph import StateGraph, END
from supervisor.state import AgentState
from agents.data_engineer.agent import DataEngineerAgent
from agents.market_analyst.agent import MarketAnalystAgent
from agents.ops_coordinator.agent import OpsCoordinatorAgent
from agents.business_dev.agent import BusinessDevAgent

def build_graph():
    print("Initializing agents...")
    da = DataEngineerAgent()
    ma = MarketAnalystAgent()
    oc = OpsCoordinatorAgent()
    bd = BusinessDevAgent()
    print("Agents initialized successfully")

    workflow = StateGraph(AgentState)
    
    workflow.add_node("data_engineer", da.node_execute)
    workflow.add_node("market_analyst", ma.node_execute)
    workflow.add_node("ops_coordinator", oc.node_execute)
    workflow.add_node("business_dev", bd.node_execute)

    workflow.set_entry_point("business_dev")
    workflow.add_edge("business_dev", "data_engineer")
    workflow.add_edge("data_engineer", "ops_coordinator")
    workflow.add_edge("ops_coordinator", END)

    graph = workflow.compile()
    print("Graph compiled successfully")
    return graph

graph = build_graph()
