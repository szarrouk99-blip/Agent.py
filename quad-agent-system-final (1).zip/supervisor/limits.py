import logging
logger = logging.getLogger(__name__)

MAX_STEPS = 15
TOKEN_BUDGET = 50000

def update_token_usage(state, llm_response):
    usage = llm_response.get("usage_metadata", {})
    new_tokens = usage.get("total_tokens", 0)
    state["total_tokens_used"] = state.get("total_tokens_used", 0) + new_tokens
    state["step_count"] = state.get("step_count", 0) + 1
    return state

def check_limits(state):
    if state.get("step_count", 0) >= MAX_STEPS:
        return "halt"
    if state.get("total_tokens_used", 0) >= TOKEN_BUDGET:
        return "halt"
    return "continue"
